from django.shortcuts import render
from .models import  *
from .forms import *
from django.http import *



def home(request):
    obj = student.objects.all().order_by('-dat')

    return render(request, 'index.html', {'obj':obj})

def student1(request):

    if request.method == 'POST':
        form1 = student_form(request.POST)
        if form1.is_valid():
            form1.save()
            return HttpResponseRedirect('/studentform/')

    else:
        form1 = student_form()
    return render(request, 'student.html', {'form':form1})




# Create your views here.
