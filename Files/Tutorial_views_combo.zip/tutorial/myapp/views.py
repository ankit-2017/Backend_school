from django.shortcuts import render
from .models import  *
from .forms import *
from django.http import *



def student1(request):
    obj = student.objects.all().order_by('-dat')
    if request.method == 'POST':
        form = student_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/studentform/')

    else:
        form = student_form()
    return render(request, 'student.html', {'form':form, 'obj':obj})



# Create your views here.
