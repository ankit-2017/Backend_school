from django.shortcuts import render
from .models import  *
from .forms import *
from django.http import *



def home(request):
    obj = student.objects.all().order_by('-dat')

    return render(request, 'index.html', {'obj':obj})

def student1(request):

    if request.method == 'POST':
        form = student_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/studentform/')

    else:
        form = student_form()
    return render(request, 'student.html', {'form':form})



# Create your views here.
