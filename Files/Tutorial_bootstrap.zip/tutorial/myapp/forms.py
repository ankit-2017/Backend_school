from django import forms
from .models import *

class student_form(forms.ModelForm):
    name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Enter your name'}), required=True, max_length=100)
    emailid = forms.CharField(widget=forms.EmailInput(attrs={'class':'form-control','placeholder':'Enter your Email'}), required=True, max_length=100)
    city = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Enter your city'}), required=False, max_length=100)
    marks = forms.CharField(widget=forms.NumberInput(attrs={'class':'form-control','placeholder':'Enter your marks'}), required=True, max_length=10)

    class Meta():
        model = student
        fields = ['name','emailid','city','marks']


